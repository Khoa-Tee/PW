// config/credentials.js
export const username = 'superuser+demo01@blixo.com';
export const pw = '9eO7b09sno1b5qc';
export const customername = 'Karl To';
