export const addInvoiceButton = "xpath=//button[@type='button' and .//span[text()='Add invoice']]";
export const createNewOneButton = "xpath=(//span[text()='Create a new one'])[1]";
export const deletedSuccessContent = "xpath=//div[text()='Your invoice was deleted']";
export const closeIconOfPushNotification = "xpath=//div[contains(@class, 'ant-notification-notice')]//a[contains(@class, 'ant-notification-notice-close')]";
export const closeIconOfPushNotification2 = "xpath=(//div[contains(@class, 'ant-notification-notice')]//a[contains(@class, 'ant-notification-notice-close')])[2]";
export const closeIconOfPushNotification3 = "xpath=(//div[contains(@class, 'ant-notification-notice')]//a[contains(@class, 'ant-notification-notice-close')])[3]";
