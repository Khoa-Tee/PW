// config/credentials.js
export const invoiceSection = "xpath=//a[@href='/invoices']";
export const customerSection = "xpath=//a[@href='/customers']";

