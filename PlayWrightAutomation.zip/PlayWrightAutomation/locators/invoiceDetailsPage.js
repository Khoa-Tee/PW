export const draftStatus1 = "xpath=(//span[text()='DRAFT'])[1]";
export const draftStatus2 = "xpath=(//span[text()='DRAFT'])[2]";
export const moreButton = "xpath=//span[text()='More...']";
export const deleteInvoiceButton = "xpath=//span[text()='Delete Invoice']";
export const confirmQuestion = "xpath=//div[text()='Do you want to delete this invoice?']";   
export const okButton = "xpath=//span[text()='OK']";
export const successPushNotificationContent = "xpath=//div[text()='New Invoice has been added.']";