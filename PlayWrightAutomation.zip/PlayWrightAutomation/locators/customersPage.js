export const addCustomerButton = "xpath=//button[@type='button' and .//span[text()='Add customer']]";
export const customerSearchBar = "xpath=//input[@type='search']";
export const customerName = "xpath=//div[@title='Karl To']";
export const anticonCheckSearchBar = "xpath=//span[@class='anticon anticon-check']";
export const customerNumber = "xpath=//span[text()='CUS-0004']";
